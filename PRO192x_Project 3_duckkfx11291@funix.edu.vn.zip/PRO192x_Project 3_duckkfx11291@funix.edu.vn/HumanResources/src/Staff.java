import java.math.BigDecimal;
import java.math.RoundingMode;

public abstract class Staff {
    private String id_nv;
    private String name_nv;
    private int age_nv;
    private double coefficients_salary;
    private String start_date;
    private Department department;
    private int number_days_off;

    //constructor cho Staff
    public Staff(String id_nv, String name_nv, int age_nv, double coefficients_salary, String start_date, Department department, int number_days_off) {
        this.id_nv = id_nv;
        this.name_nv = name_nv;
        this.age_nv = age_nv;
        this.coefficients_salary = coefficients_salary;
        this.start_date = start_date;
        this.department = department;
        this.number_days_off = number_days_off;
    }

    //getter và setter cho Staff
    public String getId_nv() {
        return id_nv;
    }

    public void setId_nv(String id_nv) {
        this.id_nv = id_nv;
    }

    public String getName_nv() {
        return name_nv;
    }

    public void setName_nv(String name_nv) {
        this.name_nv = name_nv;
    }

    public int getAge_nv() {
        return age_nv;
    }

    public void setAge_nv(int age_nv) {
        this.age_nv = age_nv;
    }

    public double getCoefficients_salary() {
        return coefficients_salary;
    }

    public void setCoefficients_salary(double coefficients_salary) {
        this.coefficients_salary = coefficients_salary;
    }

    public String getStart_date() {
        return start_date;
    }

    public void setStart_date(String start_Date) {
        this.start_date = start_date;
    }

    public Department getDepartment() {
        return department;
    }

    public void setDepartment(Department department) {
        this.department = department;
    }

    public int getNumber_days_off() {
        return number_days_off;
    }

    public void setNumber_days_off(int number_days_off) {
        this.number_days_off = number_days_off;
    }

    //phương thức hiển thị thông tin
    public abstract void displayInformation();

}
