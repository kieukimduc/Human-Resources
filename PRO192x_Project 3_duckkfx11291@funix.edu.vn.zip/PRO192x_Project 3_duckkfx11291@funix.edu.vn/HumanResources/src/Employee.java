public class Employee extends Staff implements ICalculator{
    private double overtime_hours;

    //constructor cho employee
    public Employee(String id_nv, String name_nv, int age_nv, double coefficients_salary, String start_date,Department department, int number_days_off, double overtime_hours) {
        super(id_nv, name_nv, age_nv, coefficients_salary, start_date,department, number_days_off);
        department.setCurrent_number_employees(department.getCurrent_number_employees()+ 1);
        this.overtime_hours = overtime_hours;
    }


    //getter và setter cho employee
    public double getOvertime_hours() {
        return overtime_hours;
    }

    public void setOvertime_hours(double overtime_hours) {
        this.overtime_hours = overtime_hours;
    }

    //viết lại phương thức tính lương cho nhân viên
    @Override
    public double calculateSalary() {
        return getCoefficients_salary()*3000000+overtime_hours*200000;
    }

    //viết lại phương thức hiển thị thông tin nhân viên
    @Override
    public void displayInformation() {


        System.out.printf("%-20s|",getId_nv());
        System.out.printf(" %-25s|",getName_nv());
        System.out.printf(" %-15d|",getAge_nv());
        System.out.printf(" %-15.1f|",getCoefficients_salary());
        System.out.printf(" %-25s|",getStart_date());
        System.out.printf(" %-20d|",getNumber_days_off());
        System.out.printf(" %-30s|",getDepartment().getName_department());
        System.out.printf(" %-30.1f|",getOvertime_hours());
        System.out.printf(" %.2f",calculateSalary());

    }
}
