public class Manager extends Staff implements ICalculator {
    private String job_title;

    //constructor cho manager
    public Manager(String id_nv, String name_nv, int age_nv, double coefficients_salary, String start_date, Department department, int number_days_off, String job_title) {
        super(id_nv, name_nv, age_nv, coefficients_salary, start_date, department, number_days_off);
        department.setCurrent_number_employees(department.getCurrent_number_employees()+ 1);
        this.job_title = job_title;
    }
    //getter và setter cho class Manager
    public String getJob_title() {
        return job_title;
    }

    public void setJob_title(String job_title) {
        this.job_title = job_title;
    }

    // viết lại phương thức tính lương cho quản lý
    @Override
    public double calculateSalary() {
        double salary = getCoefficients_salary() * 5000000;
        String title = getJob_title();
        title = title.toLowerCase();
        //tiền lương được tính dựa vào chức  vụ của mỗi người
        switch (title) {
            case "business leader":
                salary += 8000000;
                break;
            case "project leader":
                salary += 5000000;
                break;
            case "technical leader":
                salary += 6000000;
                break;

        }

        return salary;
    }

    //viết lại phương thức hiển thị thông tin của quản lý
    @Override
    public void displayInformation() {


        System.out.printf("%-20s|",getId_nv());
        System.out.printf(" %-25s|",getName_nv());
        System.out.printf(" %-15d|",getAge_nv());
        System.out.printf(" %-15.1f|",getCoefficients_salary());
        System.out.printf(" %-25s|",getStart_date());
        System.out.printf(" %-20d|",getNumber_days_off());
        System.out.printf(" %-30s|",getDepartment().getName_department());
        System.out.printf(" %-30s|",getJob_title());
        System.out.printf(" %.2f",calculateSalary());


    }
}
