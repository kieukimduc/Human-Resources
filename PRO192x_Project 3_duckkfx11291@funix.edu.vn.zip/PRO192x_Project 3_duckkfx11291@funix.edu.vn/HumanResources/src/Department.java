import java.util.ArrayList;
import java.util.List;

public class Department {
    protected String id_department;
    protected String name_department;
    protected int current_number_employees;
    protected ArrayList<Staff> staff=new ArrayList<Staff>();

    //constructor cho Swpartment
    public Department(String id_department, String name_department){
        this.id_department = id_department;
        this.name_department = name_department;
        this.current_number_employees = 0;


    }

    //getter và setter cho department
    public String getId_department() {

        return id_department;
    }

    public void setId_department(String id_department) {

        this.id_department = id_department;
    }

    public String getName_department() {

        return name_department;
    }

    public void setName_department(String name_department) {

        this.name_department = name_department;
    }

    public int getCurrent_number_employees() {
        return current_number_employees;
    }

    public void setCurrent_number_employees(int current_number_employees) {
        this.current_number_employees = current_number_employees;
    }





    //viết đè phương thức hiển thị thông tin cho bộ phận
    @Override
    public String toString() {
        return String.format("%-25s| %-40s| %d",id_department,name_department,current_number_employees);
    }
}
