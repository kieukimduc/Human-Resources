public interface ICalculator {
    //phương thức tính lương
    public double calculateSalary();
}
