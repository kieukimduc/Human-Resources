import java.util.*;

public class HumanResources {

    private static final ArrayList<Department> DEPARTMENTS = new ArrayList<>();// danh sách bộ phận công ty

    //các bộ phận của công ty
    private static final Department DT1 = new Department("HC", "Hành chính nhân sự");
    private static final Department DT2 = new Department("IT", "Công nghệ thông tin");
    private static final Department DT3 = new Department("MKT", "Marketing");


    private static final ArrayList<Staff> STAFFS= new ArrayList<>();//danh sách nhân viên

    private static final Scanner SC = new Scanner(System.in);

    public static void main(String[] args) {
        init();
        run();
    }

    //menu chương trình
    private static void run() {
        int luaChonSo;
        do {
            System.out.println();
            System.out.println("1. Hiển thị danh sách nhân viên hiện có trong công ty.");
            System.out.println("2. Hiển thị các bộ phận trong công ty.");
            System.out.println("3. Hiển thị các nhân viên theo từng bộ phận.");
            System.out.println("4. Thêm nhân viên mới vào công ty.");
            System.out.println("5. Tìm kiếm thông tin nhân viên theo tên hoặc mã nhân viên");
            System.out.println("6. Hiển thị bảng lương của nhân viên toàn công ty.");
            System.out.println("7. Hiển thị bảng lương của nhân viên  theo thứ tự tăng dần.");
            System.out.println("0. Thoát chương trình.");
            System.out.print("Lựa chọn của bạn: ");
            luaChonSo = SC.nextInt();
            switch (luaChonSo) {
                case 1:
                    displayListOfEmployees();
                    break;
                case 2:
                    displayListOfDepartments();
                    break;
                case 3:
                    displayListOfEmployeesInDepartment();
                    break;
                case 4:
                    addNewStaff();
                    break;
                case 5:
                    searchEmployee();
                    break;
                case 6:
                    displaySalaryInDescendingOrder();
                    break;
                case 7:
                    displaySalaryInAscendingOrder();
                    break;
                case 0:
                    System.out.println("Cảm ơn bạn đã dùng chương trình");
                    break;

                default:
                    System.out.println("Lựa chọn không hợp lệ. Vui lòng chọn lại");
                    break;
            }

        } while (luaChonSo != 0);

    }

    //khởi tạo các nhân viên vào danh sách
    private static void init() {
        //thêm các bộ phân vào công ty
        DEPARTMENTS.add(DT1);
        DEPARTMENTS.add(DT2);
        DEPARTMENTS.add(DT3);

        //khởi tạo nhân viên
        Employee el1 = new Employee("M01", "Nguyễn Văn An", 21, 4.5, "10/10/2022", DT2, 10, 35.5);
        Employee el2 = new Employee("M02", "Kiều Kim An", 21, 7.7, "10/10/2020", DT1, 3, 12.5);
        Employee el3 = new Employee("M02", "Kiều Kim Thắng", 21, 6.5, "10/10/2020", DT1, 3, 31.8);
        Employee el4 = new Employee("M02", "Kiều Bằng", 21, 4.5, "10/10/2020", DT1, 3, 25);
        Manager mg1 = new Manager("VIP1", "Phan Văn Tài", 35, 9.5, "1/3/2015", DT1, 1, "Business Leader");
        Manager mg2 = new Manager("VIP2", "Trần Văn Đức", 35, 8.5, "1/3/2016", DT2, 1, "Project Leader");

        //thêm nhân viên vào danh sách
        STAFFS.add(el1);
        STAFFS.add(el2);
        STAFFS.add(el3);
        STAFFS.add(el4);
        STAFFS.add(mg1);
        STAFFS.add(mg2);


    }

    //hiển thị toàn bộ nhân viên của công ty
    private static void displayListOfEmployees() {
        if (STAFFS.isEmpty()) {
            System.out.println("Hiện tại trong công ty không có nhân viên");
        } else {
            System.out.printf("%-20s| %-25s| %-15s| %-15s| %-25s| %-20s| %-30s| %-30s| %s\n", "Mã nhân viên", "Tên nhân viên", "Tuổi", "HS Lương", "Ngày vào làm", "Ngày nghỉ phép", "Bộ phận", "Số giờ làm thêm/Chức vụ", "Lương");
            System.out.println("---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");

            //duyệt tất cả nhân viên có trong công ty
            for (Staff staff : STAFFS) {
                staff.displayInformation();
                System.out.println();
            }
        }
    }

    //Hiển thị các bộ phận trong công ty
    private static void displayListOfDepartments() {
        if (DEPARTMENTS.isEmpty()) { //kiểm xem trong công ty có tồn tại bộ phận nào không
            System.out.println("Không có bộ phận nào trong công ty");
        } else {
            System.out.printf("%-25s| %-40s| %s\n", "Mã bộ phận", "Tên bộ phận", "Số lượng nhân viên hiện tại");
            System.out.println("------------------------------------------------------------------------------------------------");

            //duyệt tất cả bô phận có trong công ty
            for (Department dtm : DEPARTMENTS) {
                System.out.println(dtm.toString());

            }
        }
    }

    //Hiển thị các nhân viên theo từng bộ phận
    private static void displayListOfEmployeesInDepartment() {

        if (DEPARTMENTS.isEmpty()) {
            System.out.println("Không có bộ phận nào trong công ty");
        } else {
            for (Department department : DEPARTMENTS) { //duyệt các bộ phận trong công ty
                System.out.println(department.getName_department());
                System.out.println("---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");
                System.out.printf("%-20s| %-25s| %-15s| %-15s| %-25s| %-20s| %-30s| %-30s| %s\n", "Mã nhân viên", "Tên nhân viên", "Tuổi", "HS Lương", "Ngày vào làm", "Ngày nghỉ phép", "Bộ phận", "Số giờ làm thêm/Chức vụ", "Lương");
                for (Staff staff : STAFFS) { //duyệt các nhân viên trong công ty
                    if (staff.getDepartment().equals(department)) { //phân loại nhân viên theo từng bộ phận
                        staff.displayInformation();
                        System.out.println();
                    }


                }
                System.out.println();
            }
        }

    }

    //Thêm nhân viên mới vào công ty
    private static void addNewStaff() {
        System.out.println("1. Thêm nhân viên thông thường");
        System.out.println("2. Thêm nhân viên là cấp quản lý (có thêm chức vụ)");

        //nhập thông tin cơ bản cho nhân viên
        System.out.print("Bạn chọn: ");
        int luaChonNv = SC.nextInt();
        System.out.print("Nhập mã nhân viên: ");
        String idNv = SC.next();
        SC.nextLine();
        System.out.print("Nhập tên nhân viên: ");
        String tenNv = SC.nextLine();
        System.out.print("Nhâp tuổi nhân viên: ");
        int ageNv = SC.nextInt();
        System.out.print("Nhập hệ số lương của nhân viên: ");
        double hsLuong = SC.nextDouble();
        SC.nextLine();
        System.out.print("Nhập ngày vào làm của nhân viên: ");
        String startDay = SC.nextLine();
        System.out.print("Nhập số ngày nghỉ phép của nhân viên: ");
        int dayOff = SC.nextInt();
        System.out.println("1. HC - Hành chính nhân sự");
        System.out.println("2. IT - Công nghệ thông tin");
        System.out.println("3. MKT - Marketing");
        System.out.print("Bạn chọn bộ phận: ");
        int luaChonBp = SC.nextInt();

        //kiểm tra xem là nhân viên hay quản lý
        if (luaChonNv == 1) {

            System.out.print("Nhập số giờ làm thêm: ");
            double ovTime = SC.nextDouble();
            //lựa chọn bộ phận cho nhân viên
            if (luaChonBp == 1) {
                Employee newEmployee = new Employee(idNv, tenNv, ageNv, hsLuong, startDay, DT1, dayOff, ovTime);
                STAFFS.add(newEmployee);
            } else if (luaChonBp == 2) {
                Employee newEmployee = new Employee(idNv, tenNv, ageNv, hsLuong, startDay, DT2, dayOff, ovTime);
                STAFFS.add(newEmployee);
            } else if (luaChonBp == 3) {
                Employee newEmployee = new Employee(idNv, tenNv, ageNv, hsLuong, startDay, DT3, dayOff, ovTime);
                STAFFS.add(newEmployee);
            }
        } else if (luaChonNv == 2) {
            SC.nextLine();
            System.out.print("Chức danh: ");
            String chucDanh = SC.nextLine();
            //lựa chọn bộ phận cho quản lý
            if (luaChonBp == 1) {
                Manager mn = new Manager(idNv, tenNv, ageNv, hsLuong, startDay, DT1, dayOff, chucDanh);
                STAFFS.add(mn);
            } else if (luaChonBp == 2) {
                Manager mn = new Manager(idNv, tenNv, ageNv, hsLuong, startDay, DT2, dayOff, chucDanh);
                STAFFS.add(mn);
            } else if (luaChonBp == 3) {
                Manager mn = new Manager(idNv, tenNv, ageNv, hsLuong, startDay, DT3, dayOff, chucDanh);
                STAFFS.add(mn);
            }
        }

    }

    //tìm kiếm nhân viên theo tên hoặc mã nhân viên
    private static void searchEmployee() {
        List<Staff> nv=new ArrayList<>();

        System.out.println("1. Tìm nhân viên bằng tên");
        System.out.println("2. Tìm nhân viên bằng mã nhân viên");
        int luaChon = SC.nextInt();
        SC.nextLine();
        if (luaChon == 1) {

            System.out.println("Nhập tên nhân viên cần tìm:");
            String tenNv = SC.nextLine();

            for (Staff staff : STAFFS) {

                if (staff.getName_nv().endsWith(tenNv)) {
                   nv.add(staff);
                }

            }
        } else if (luaChon == 2) {
            System.out.println("Nhập mã nhân viên cần tìm:");
            String idNv = SC.nextLine();

            for (Staff staff : STAFFS) {
                if (staff.getId_nv().equalsIgnoreCase(idNv)) {
                    nv.add(staff);
                }


            }
        }

        //kiểm tra xem có tồn tại nhân viên hay quản lý không
        if (!(nv.isEmpty()))
        {
            System.out.printf("%-20s| %-25s| %-15s| %-15s| %-25s| %-20s| %-30s| %-30s| %s\n", "Mã nhân viên", "Tên nhân viên", "Tuổi", "HS Lương", "Ngày vào làm", "Ngày nghỉ phép", "Bộ phận", "Số giờ làm thêm/Chức vụ", "Lương");
            for (Staff st:nv) {
                st.displayInformation();
                System.out.println();
            }
        }else
        {
            System.out.println("Không tìm thấy nhân viên cần tìm");
        }


    }

    //hiển thị lương của toàn bộ nhân viên theo thứ tự giảm dần
    private static void displaySalaryInDescendingOrder() {
        STAFFS.sort((o1, o2) -> {
            double l1 = 0;
            double l2 = 0;
            if (o1 instanceof Employee) { //kiểm tra xem o1 có thuộc employee không
                l1 = ((Employee) o1).calculateSalary();
            }
            if (o1 instanceof Manager) { //kiểm tra xem o1 có thuộc manager không
                l1 = ((Manager) o1).calculateSalary();
            }
            if (o2 instanceof Employee) { //kiểm tra xem o2 có thuộc employee không
                l2 = ((Employee) o2).calculateSalary();
            }
            if (o2 instanceof Manager) { //kiểm tra xem o2 có thuộc manager không
                l2 = ((Manager) o2).calculateSalary();
            }

            if (l1 < l2)
                return 1;
            else if (l1 > l2) {
                return -1;
            }
            return 0;
        });

        //hiển thị nhân viên sau khi đã được sắp xếp
        System.out.printf("%-20s| %-25s| %-15s| %-15s| %-25s| %-20s| %-30s| %-30s| %s\n", "Mã nhân viên", "Tên nhân viên", "Tuổi", "HS Lương", "Ngày vào làm", "Ngày nghỉ phép", "Bộ phận", "Số giờ làm thêm/Chức vụ", "Lương");
        for (Staff staff : STAFFS) {
            staff.displayInformation();
            System.out.println();
        }
    }

    //Hiển thị bảng lương của nhân viên theo thứ tự tăng dần
    private static void displaySalaryInAscendingOrder() {

        STAFFS.sort((o1, o2) -> {
            double l1 = 0;
            double l2 = 0;
            if (o1 instanceof Employee) { //kiểm tra xem o1 có thuộc employee không
                l1 = ((Employee) o1).calculateSalary();
            }
            if (o1 instanceof Manager) { //kiểm tra xem o1 có thuộc manager không
                l1 = ((Manager) o1).calculateSalary();
            }
            if (o2 instanceof Employee) { //kiểm tra xem o2 có thuộc employee không
                l2 = ((Employee) o2).calculateSalary();
            }
            if (o2 instanceof Manager) { //kiểm tra xem o2 có thuộc manager không
                l2 = ((Manager) o2).calculateSalary();
            }

            if (l1 > l2)
                return 1;
            else if (l1 < l2) {
                return -1;
            }
            return 0;
        });

        //hiển thị nhân viên sau khi đã được sắp xếp
        System.out.printf("%-20s| %-25s| %-15s| %-15s| %-25s| %-20s| %-30s| %-30s| %s\n", "Mã nhân viên", "Tên nhân viên", "Tuổi", "HS Lương", "Ngày vào làm", "Ngày nghỉ phép", "Bộ phận", "Số giờ làm thêm/Chức vụ", "Lương");
        for (Staff staff : STAFFS) {
            staff.displayInformation();
            System.out.println();
        }


    }
}
